<nav>
    <ul>
        <a href="index.php?state=shop">
            <li>Sklep</li>
        </a>
        <a href="index.php?state=auctions">
            <li>Aukcje użytkowników</li>
        </a>
        <a href="index.php?state=galery">
            <li>Galeria</li>
        </a>
        <a href="index.php?state=news">
            <li>Ogłoszenia</li>
        </a>
        <a href="index.php?state=zawody">
            <li>Zawody</li>
        </a>
        <a href="index.php?state=o_nas">
            <li>O Nas</li>
        </a>
    </ul>
</nav>