<div id="social-media-container">
        <a href="https://www.facebook.com/">
            <div id="facebook">
                <i class="icon-facebook-squared"></i>
            </div>
        </a>
        <a href="https://twitter.com/home?lang=pl">
            <div id="twitter">
                <i class="icon-twitter"></i>
            </div>
        </a>
        <a href="https://www.instagram.com/">
            <div id="instagram">
                <i class="icon-instagram"></i>
            </div>
        </a>
        <a href="https://myaccount.google.com/intro/profile">
            <div id="google">
                <i class="icon-gplus"></i>
            </div>
        </a>
    </div>
    <footer>
        Copyright &copy; 2020 - 2021 All rights reserved
    </footer>